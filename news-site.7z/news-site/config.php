<?php
$hostname = "http://localhost/news-site";

$conn = mysqli_connect("localhost","root","","news_blog") or die("Connection failed : " . mysqli_connect_error());

?>
